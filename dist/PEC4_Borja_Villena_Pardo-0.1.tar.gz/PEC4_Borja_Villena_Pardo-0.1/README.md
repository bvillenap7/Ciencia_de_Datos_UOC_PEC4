# PEC4
## Autor: Borja Villena Pardo
### Asignatura: Programación para Ciencia de Datos

***This software is MIT licensed (see LICENSE)***

Este proyecto forma parte del entregable para la PEC_4 de la
asignatura *Programación para Ciencia de Datos*, includia en el
*Grado de Ingeniería en Ciencia de Datos Aplicada*, cursada en 
*Universidad Oberta de Catalunya, UOC*.

A continuación puede encontrar una breve descripción
de como se organiza y ejecuta nuestro proyecto.

Nuestro repositorio de carpetas se organiza de la siguiente
manera dentro de nuestro proyecto en PyCharm:

- PEC4_Borja Villena Pardo
  - data
    - __ init.py __
    - TMDB.zip
    
  - dist
    - PEC4_Borja_Villena_Pardo-0.1.tar.gz
    
  - PEC4_Borja_Villena_Pardo.egg-info
    - dependency_links.txt
    - PKG-INFO
    - requires.txt
    - SOURCES.txt
    - top_level.txt
    
  - src
    - __ init __.py
    - Ejercicio_1_1.py
    - Ejercicio_1_2.py
    - Ejercicio_1_3.py
    - Ejercicio_1_4.py
    - Ejercicio_2_1.py
    - Ejercicio_2_2.py
    - Ejercicio_3_1.py
    - Ejercicio_3_2.py
    - Ejercicio_3_3.py
    - Ejercicio_4_1.py
    - Ejercicio_4_2.py
    - Ejercicio_4_3.py
    - Ejercicio_5.py
    - main.py
  - Tests
    - data
    - test.txt
    - test_Ejercicio_1_1.py
    - test_Ejercicio_1_2.py
    - test_Ejercicio_1_3.py
    - test_Ejercicio_2_1.py
    - test_Ejercicio_2_2.py
    - test_Ejercicio_3_1.py
    - test_Ejercicio_3_2.py
    - test_Ejercicio_3_3.py
    - test_Ejercicio_4_1.py
    - test_Ejercicio_4_2.py
    - test_Ejercicio_4_3.py
  - venv
    - Include
    - Lib 
      - *(...)*
    - Scripts
      - *(...)*
    - share
      - *(...)*
    - pyvenv.cfg
  - __ init.py __
  - LICENSE.txt
  - main.py
  - README.md
  - requirements.txt
  - setup.py

    
Para llevar a cabo la instalación del ***setup.py***
lleve a cabo los siguientes pasos:

- Vaya a la siguiente subcarpeta de nuestro proyecto: ***dist***
- Copiese el archivo ***PEC4_Borja_Villena_Pardo-0.1.tar.gz++ y peguelo
en la ruta local que desee.
- Abra un terminal en local, navegue hasta el directorio dónde haya copiado y guardado
el archivo.
- Escriba: *pip install -Nombre completo del archivo-*
- En nuestro caso sería: ***pip install PEC4_Borja Villena Pardo-0.1.tar.gz***
- Una vez instalado, descomprima el repositorio. Botón derecho sobre la
carpeta comprimida, descomprimir.
- **MUY IMPORTANTE** Entre en el directorio descomprimido y copie la BBDD comprimida con la que desea 
trabajar en la subcarpeta ***PEC4_Borja_Villena_Pardo-0.1\data***. Sin este paso
nuestro programa no funcionaría correctamente.
Nota: en la subcarpeta ***data*** de nuestro proyecto puede encontrar disponible el 
archivo de la BBDD ***TMDB.zip***. Úselo si lo desea.
- Una vez copiada la BBDD en la ruta especificada del repositorio una vez descomprimido, 
navegaremos en el terminal hasta llegar al archivo main.py. Este archivo se encuentra en
la siguiente ruta relativa del repositorio descomprimido:
***..\PEC4_Borja_Villena_Pardo-0.1\PEC4_Borja_Villena_Pardo-0.1\src***
- Una vez ubicados en esta ruta, ejecutaremos nuestro programa escribiendo en el terminal:
***python main.py***
Nota: puede que si le de error deba de escribir en su lugar: ***python3 main.py***
- Acabamos de ejecutar nuestro programa. A partir de este momento seguiremos las indicaciones 
que nos devuelva el programa a través del terminal.