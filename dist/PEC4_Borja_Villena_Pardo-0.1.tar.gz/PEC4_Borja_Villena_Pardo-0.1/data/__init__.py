# This software is MIT licensed (see LICENSE)

# Este archivo sirve para que Python identifique
# a la carpeta que lo contiene como un directorio
# de paquetes de Python, es decir, para que trate
# este directorio como módulos o submódulos.
